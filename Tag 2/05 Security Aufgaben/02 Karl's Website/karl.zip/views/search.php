<?php
// Suche musst Du noch machen, KArl!
?>

<h1>Suchergebnisse</h1>

<p>Deine Suche nach "<?= $_POST['q'] ?? '' ?>" lieferte keine Treffer!</p>